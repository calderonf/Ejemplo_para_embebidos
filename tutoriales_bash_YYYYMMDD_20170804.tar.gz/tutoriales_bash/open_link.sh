#open tutorial

firefox "http://linuxconfig.org/bash-scripts-to-scan-and-monitor-network"
