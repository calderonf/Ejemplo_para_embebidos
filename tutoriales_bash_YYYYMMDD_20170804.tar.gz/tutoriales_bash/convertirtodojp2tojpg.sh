#!/bin/bash



echo "Se convertiran los archivos"
find -type f -iname "*.jp2" -exec bash -c 'echo "{}"' \;


echo "Oprima \"y\" y enter para convertir todo. \"n\" u otra entrada para cancelar"

read ENTRADA

if [ "$ENTRADA" = "y" ]; then
    echo "Convirtiendo"
    find -type f -iname "*.jp2" -exec bash -c './jp2tojpg.sh "{}"' \;

    echo "Las carpetas quedan:"
    echo "----"
    find -name "*" -exec bash -c 'echo "{}"' \;
    echo "----"
else
    echo "No se convierte nada"
fi

