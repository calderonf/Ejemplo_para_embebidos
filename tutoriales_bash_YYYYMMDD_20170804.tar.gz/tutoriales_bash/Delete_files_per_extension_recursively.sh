# !/bin/sh

echo "this script removes all files recursively please open the script and modify it acording to your needs. "
 
echo "the files to be deleted are:"
find . -name "*.csv" -type f

echo "uncomment the following lone to remove."
#find . -name "*.csv" -type f -delete