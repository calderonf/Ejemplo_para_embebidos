#!/bin/bash
FILE=$1
a=$FILE

xpath=${a%/*} 
xbase=${a##*/}
xfext=${xbase##*.}
xpref=${xbase%.*}



NAME=${xpref}
EXTENSION=${xfext}
PATHTOFILE=${xpath}


echo "Convirtiendo archivo $FILE a $PATHTOFILE/$NAME.jpg"

convert "$FILE" -quality 85% "$PATHTOFILE/$NAME.jpg"






