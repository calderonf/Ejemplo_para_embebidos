# Only works in Bash
my_func() {
   echo in my_func $1
}
export -f my_func
parallel my_func ::: 1 2 3


