#!/bin/bash
# EJECUTAR COMANDOS DESDE BASH


# use backticks " ` ` " to execute shell command
echo `uname -o`
# executing bash command without backticks
echo uname -o 
