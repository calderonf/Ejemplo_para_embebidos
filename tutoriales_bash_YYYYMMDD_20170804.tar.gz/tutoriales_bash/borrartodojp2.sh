#!/bin/bash



echo "Se borran los archivos"
find -type f -iname "*.jp2" -exec bash -c 'echo "{}"' \;


echo "y para borrar todo n u otra entrada para cancelar"

read ENTRADA

if [ "$ENTRADA" = "y" ]; then
    echo borrando
    find -type f -iname "*.jp2" -exec bash -c 'echo borrando "{}" ;rm -f "{}"' \;

    echo "Las carpetas quedan:"
    echo "----"
    find -iname "*.jp2" -exec bash -c 'echo "{}"' \;
    echo "----"
else
    echo "No se borra nada"
fi

