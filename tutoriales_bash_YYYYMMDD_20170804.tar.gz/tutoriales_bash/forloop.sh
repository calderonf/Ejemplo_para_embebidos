#/bin/sh

if [ $# = "0" ]
then
echo "como no pidio nada se toma N=5"
N="5"
fi
N=$1

for (( i=1; i <= $(eval echo $N); i++ ))
do
   echo "first for $i times"
done 


for i in $(eval echo {1..$N})
do echo "Second For $i of $N"
done